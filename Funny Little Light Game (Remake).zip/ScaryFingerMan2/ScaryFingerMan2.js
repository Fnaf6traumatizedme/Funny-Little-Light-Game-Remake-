/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class ScaryFingerMan2 extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./ScaryFingerMan2/costumes/costume1.svg", {
        x: 59.18703655602664,
        y: 75.99964704672396,
      }),
    ];

    this.sounds = [new Sound("pop", "./ScaryFingerMan2/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(Trigger.CLONE_START, this.startAsClone2),
      new Trigger(Trigger.CLONE_START, this.startAsClone3),
      new Trigger(Trigger.CLONE_START, this.startAsClone4),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.CLONE_START, this.startAsClone5),
      new Trigger(Trigger.CLONE_START, this.startAsClone6),
      new Trigger(
        Trigger.BROADCAST,
        { name: "granpa joe is coming" },
        this.whenIReceiveGranpaJoeIsComing
      ),
    ];

    this.vars.timeFlashLightOn = -1.942890293094024e-16;
  }

  *startAsClone() {
    while (true) {
      if (this.compare(this.vars.timeFlashLightOn, 0.4) > 0) {
        this.stage.vars.murdersCommited++;
        yield* this.wait(0);
        this.deleteThisClone();
      }
      yield;
    }
  }

  *startAsClone2() {
    while (true) {
      for (let i = 0; i < 25; i++) {
        yield* this.glide(0.5, this.random(-227, 227), this.random(-148, 148));
        yield* this.glide(
          0.5,
          this.sprites["Sprite1"].x,
          this.sprites["Sprite1"].y
        );
        yield;
      }
      this.y = this.random(-1000, 1000);
      this.x = this.random(-227, 227);
      yield* this.wait(0);
      yield* this.glide(
        0.75,
        this.sprites["Sprite1"].x,
        this.sprites["Sprite1"].y
      );
      yield;
    }
  }

  *startAsClone3() {
    this.visible = true;
  }

  *startAsClone4() {
    while (true) {
      if (this.touching(Color.rgb(255, 251, 150))) {
        this.vars.timeFlashLightOn += 0.3;
        this.effects.ghost = 0;
      } else {
        this.effects.ghost = 99;
        if (this.compare(this.vars.timeFlashLightOn, 0) > 0) {
          this.vars.timeFlashLightOn -= 0.1;
        }
      }
      yield;
    }
  }

  *whenGreenFlagClicked() {
    this.stage.vars.timeSurvived = 0;
    this.stage.watchers.timeSurvived.visible = false;
    this.stage.vars.murdersCommited = 0;
    while (true) {
      this.y = this.random(-148, 148);
      this.x = this.random(-227, 227);
      this.effects.ghost = 99;
      yield;
    }
  }

  *startAsClone5() {
    this.visible = true;
    while (true) {
      if (this.touching(Color.rgb(255, 255, 255))) {
        yield* this.wait(25);
        this.broadcast("dead");
      }
      yield;
    }
  }

  *startAsClone6() {
    while (true) {
      this.direction = this.radToScratch(
        Math.atan2(
          this.sprites["Sprite1"].y - this.y,
          this.sprites["Sprite1"].x - this.x
        )
      );
      yield;
    }
  }

  *whenIReceiveGranpaJoeIsComing() {
    for (let i = 0; i < 50; i++) {
      this.createClone();
      yield* this.wait(0.25);
      yield;
    }
  }
}
