/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Sprite1 extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Sprite1/costumes/costume1.svg", {
        x: 22,
        y: 62.78381644503327,
      }),
      new Costume("costume2", "./Sprite1/costumes/costume2.svg", {
        x: 22,
        y: 120.89787304379229,
      }),
    ];

    this.sounds = [new Sound("pop", "./Sprite1/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.BROADCAST, { name: "dead" }, this.whenIReceiveDead),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
    ];
  }

  *whenGreenFlagClicked() {
    this.stage.watchers.LongestTimeSurvived.visible = false;
    while (true) {
      this.direction = this.radToScratch(
        Math.atan2(this.mouse.y - this.y, this.mouse.x - this.x)
      );
      yield;
    }
  }

  *whenIReceiveDead() {
    this.stage.watchers.LongestTimeSurvived.visible = true;
  }

  *whenGreenFlagClicked2() {
    while (true) {
      if (
        this.compare(
          this.stage.vars.timeSurvived,
          this.stage.vars.LongestTimeSurvived
        ) > 0
      ) {
        this.stage.vars.LongestTimeSurvived = this.stage.vars.timeSurvived;
      }
      yield;
    }
  }
}
