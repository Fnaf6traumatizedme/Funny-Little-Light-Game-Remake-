import {
  Project,
  Sprite,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

import Stage from "./Stage/Stage.js";
import Sprite1 from "./Sprite1/Sprite1.js";
import Basic from "./Basic/Basic.js";
import Sprite3 from "./Sprite3/Sprite3.js";
import Fast from "./Fast/Fast.js";
import VeryFast from "./VeryFast/VeryFast.js";
import Strong from "./Strong/Strong.js";
import VeryStrong from "./VeryStrong/VeryStrong.js";
import MrBossGuy from "./MrBossGuy/MrBossGuy.js";
import TheFinalBossGrandpaJoe from "./TheFinalBossGrandpaJoe/TheFinalBossGrandpaJoe.js";
import Sprite2 from "./Sprite2/Sprite2.js";
import MiniGuy from "./MiniGuy/MiniGuy.js";
import ScaryFingerMan from "./ScaryFingerMan/ScaryFingerMan.js";
import ScaryFingerMan2 from "./ScaryFingerMan2/ScaryFingerMan2.js";
import Sprite4 from "./Sprite4/Sprite4.js";

const stage = new Stage({ costumeNumber: 1 });

const sprites = {
  Sprite1: new Sprite1({
    x: -12,
    y: -9,
    direction: 56.48199135474809,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 2,
    size: 100,
    visible: true,
    layerOrder: 1,
  }),
  Basic: new Basic({
    x: -49,
    y: 122,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 78,
    visible: true,
    layerOrder: 9,
  }),
  Sprite3: new Sprite3({
    x: 21,
    y: 22,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 2,
    size: 100,
    visible: true,
    layerOrder: 10,
  }),
  Fast: new Fast({
    x: -53,
    y: 89,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 78,
    visible: true,
    layerOrder: 8,
  }),
  VeryFast: new VeryFast({
    x: 166,
    y: -107,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 78,
    visible: true,
    layerOrder: 5,
  }),
  Strong: new Strong({
    x: -83,
    y: 83,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 78,
    visible: true,
    layerOrder: 4,
  }),
  VeryStrong: new VeryStrong({
    x: -156,
    y: -99,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 78,
    visible: true,
    layerOrder: 3,
  }),
  MrBossGuy: new MrBossGuy({
    x: -183,
    y: -86,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 78,
    visible: true,
    layerOrder: 2,
  }),
  TheFinalBossGrandpaJoe: new TheFinalBossGrandpaJoe({
    x: -186,
    y: 119,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 78,
    visible: false,
    layerOrder: 11,
  }),
  Sprite2: new Sprite2({
    x: 23.648882491721565,
    y: 26.35816896813124,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 100,
    visible: false,
    layerOrder: 14,
  }),
  MiniGuy: new MiniGuy({
    x: 33,
    y: 87,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 78,
    visible: true,
    layerOrder: 6,
  }),
  ScaryFingerMan: new ScaryFingerMan({
    x: 8,
    y: 89,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 78,
    visible: false,
    layerOrder: 7,
  }),
  ScaryFingerMan2: new ScaryFingerMan2({
    x: -161,
    y: 143,
    direction: 33.87081071038882,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 78,
    visible: false,
    layerOrder: 12,
  }),
  Sprite4: new Sprite4({
    x: 0,
    y: 141,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 100,
    visible: false,
    layerOrder: 13,
  }),
};

const project = new Project(stage, sprites, {
  frameRate: 30, // Set to 60 to make your project run faster
});
export default project;
