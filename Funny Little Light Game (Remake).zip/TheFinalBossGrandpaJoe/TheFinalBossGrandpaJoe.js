/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class TheFinalBossGrandpaJoe extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume(
        "costume1",
        "./TheFinalBossGrandpaJoe/costumes/costume1.svg",
        { x: 50.12360582812008, y: 50.122504401120125 }
      ),
      new Costume(
        "costume2",
        "./TheFinalBossGrandpaJoe/costumes/costume2.svg",
        { x: 87.64607999999998, y: 49.30091999999999 }
      ),
    ];

    this.sounds = [new Sound("pop", "./TheFinalBossGrandpaJoe/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(Trigger.CLONE_START, this.startAsClone2),
      new Trigger(Trigger.CLONE_START, this.startAsClone3),
      new Trigger(Trigger.CLONE_START, this.startAsClone4),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.CLONE_START, this.startAsClone5),
      new Trigger(Trigger.CLONE_START, this.startAsClone6),
      new Trigger(Trigger.KEY_PRESSED, { key: "9" }, this.whenKey9Pressed),
    ];

    this.vars.timeFlashLightOn = -1.942890293094024e-16;
  }

  *startAsClone() {
    while (true) {
      if (this.compare(this.vars.timeFlashLightOn, 999.9) > 0) {
        this.stage.vars.murdersCommited++;
        /* TODO: Implement stop other scripts in sprite */ null;
        yield* this.wait(0);
        this.costume = "costume2";
        yield* this.wait(5);
        this.broadcast("final boss beaten#");
        yield* this.wait(0);
        return;
      }
      yield;
    }
  }

  *startAsClone2() {
    while (true) {
      yield* this.glide(
        this.random(1, 10),
        this.sprites["Sprite1"].x,
        this.sprites["Sprite1"].y
      );
      yield;
    }
  }

  *startAsClone3() {
    this.visible = true;
  }

  *startAsClone4() {
    while (true) {
      if (this.touching(Color.rgb(255, 251, 150))) {
        this.vars.timeFlashLightOn++;
        this.effects.ghost = 0;
      } else {
        this.effects.ghost = 99;
        if (this.compare(this.vars.timeFlashLightOn, 0) > 0) {
          this.vars.timeFlashLightOn -= 0.1;
        }
      }
      yield;
    }
  }

  *whenGreenFlagClicked() {
    this.costume = "costume1";
    this.stage.vars.timeSurvived = 0;
    this.stage.watchers.timeSurvived.visible = false;
    this.stage.vars.murdersCommited = 0;
    while (true) {
      this.y = this.random(-1000, 1000);
      this.x = this.random(-227, 227);
      this.effects.ghost = 99;
      yield;
    }
  }

  *startAsClone5() {
    this.visible = true;
    while (true) {
      yield* this.wait(14.5);
      this.effects.brightness = 100;
      yield* this.wait(0.5);
      this.effects.brightness = 0;
      if (this.random(1, 2) === 1) {
        for (let i = 0; i < 25; i++) {
          this.sprites["MiniGuy"].createClone();
          yield* this.wait(0.1);
          yield;
        }
      } else {
        if (this.random(1, 6) === 1) {
          for (let i = 0; i < 10; i++) {
            this.sprites["Basic"].createClone();
            yield* this.wait(0.025);
            yield;
          }
        } else {
          if (this.random(1, 6) === 2) {
            for (let i = 0; i < 7; i++) {
              this.sprites["Fast"].createClone();
              yield* this.wait(0.5);
              yield;
            }
          } else {
            if (this.random(1, 6) === 3) {
              for (let i = 0; i < 5; i++) {
                this.sprites["Basic"].createClone();
                yield* this.wait(2.5);
                yield;
              }
            } else {
              if (this.random(1, 6) === 4) {
                for (let i = 0; i < 10; i++) {
                  this.sprites["Strong"].createClone();
                  yield* this.wait(0.5);
                  yield;
                }
              } else {
                if (this.random(1, 6) === 5) {
                  for (let i = 0; i < 5; i++) {
                    this.sprites["VeryStrong"].createClone();
                    yield* this.wait(1);
                    yield;
                  }
                } else {
                  if (this.random(1, 6) === 6) {
                    for (let i = 0; i < 1; i++) {
                      this.sprites["MrBossGuy"].createClone();
                      yield* this.wait(0.025);
                      yield;
                    }
                  } else {
                    if (this.random(1, 2) === 1) {
                      for (let i = 0; i < 1; i++) {
                        this.sprites["ScaryFingerMan"].createClone();
                        yield* this.wait(0.025);
                        yield;
                      }
                    } else {
                      if (this.random(1, 2) === 2) {
                        for (let i = 0; i < 100; i++) {
                          this.sprites["ScaryFingerMan2"].createClone();
                          yield* this.wait(0.025);
                          yield;
                        }
                      } else {
                        null;
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
      yield;
    }
  }

  *startAsClone6() {
    while (true) {
      if (this.touching(Color.rgb(255, 255, 255))) {
        this.y = this.random(-1000, 1000);
        this.x = this.random(-227, 227);
        this.effects.ghost = 99;
      }
      yield;
    }
  }

  *whenKey9Pressed() {}
}
