/* eslint-disable require-yield, eqeqeq */

import {
  Stage as StageBase,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Stage extends StageBase {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("backdrop1", "./Stage/costumes/backdrop1.svg", {
        x: 258.2582582582582,
        y: 204.2042042042042,
      }),
      new Costume("backdrop2", "./Stage/costumes/backdrop2.svg", {
        x: 258.2582582582582,
        y: 204.20421420420416,
      }),
    ];

    this.sounds = [new Sound("pop", "./Stage/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "granpa joe is coming" },
        this.whenIReceiveGranpaJoeIsComing
      ),
      new Trigger(Trigger.KEY_PRESSED, { key: "c" }, this.whenKeyCPressed),
    ];

    this.vars.murdersCommited = 89;
    this.vars.timeSurvived = 11.899999999999974;
    this.vars.LongestTimeSurvived = 0;

    this.watchers.murdersCommited = new Watcher({
      label: "Murders Commited",
      style: "normal",
      visible: true,
      value: () => this.vars.murdersCommited,
      x: 240,
      y: 180,
    });
    this.watchers.timeSurvived = new Watcher({
      label: "Time Survived",
      style: "normal",
      visible: true,
      value: () => this.vars.timeSurvived,
      x: 405,
      y: 29,
    });
    this.watchers.LongestTimeSurvived = new Watcher({
      label: "☁ Longest Time Survived",
      style: "normal",
      visible: true,
      value: () => this.vars.LongestTimeSurvived,
      x: 376,
      y: 2,
    });
  }

  *whenGreenFlagClicked() {
    this.costume = "backdrop1";
  }

  *whenIReceiveGranpaJoeIsComing() {}

  *whenKeyCPressed() {}
}
