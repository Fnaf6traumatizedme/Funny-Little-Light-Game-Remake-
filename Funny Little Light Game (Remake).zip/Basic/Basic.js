/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Basic extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Basic/costumes/costume1.svg", {
        x: 22,
        y: 21.999995000000013,
      }),
    ];

    this.sounds = [new Sound("pop", "./Basic/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(Trigger.CLONE_START, this.startAsClone2),
      new Trigger(Trigger.CLONE_START, this.startAsClone3),
      new Trigger(Trigger.CLONE_START, this.startAsClone4),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.CLONE_START, this.startAsClone5),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked3),
    ];

    this.vars.timeFlashLightOn = -1.942890293094024e-16;
  }

  *startAsClone() {
    while (true) {
      if (this.compare(this.vars.timeFlashLightOn, 2.9) > 0) {
        this.stage.vars.murdersCommited++;
        yield* this.wait(0);
        this.deleteThisClone();
      }
      yield;
    }
  }

  *startAsClone2() {
    while (true) {
      yield* this.glide(
        25,
        this.sprites["Sprite1"].x,
        this.sprites["Sprite1"].y
      );
      yield;
    }
  }

  *startAsClone3() {
    this.visible = true;
  }

  *startAsClone4() {
    while (true) {
      if (this.touching(Color.rgb(255, 251, 150))) {
        this.vars.timeFlashLightOn += 0.3;
        this.effects.ghost = 0;
      } else {
        this.effects.ghost = 99;
        if (this.compare(this.vars.timeFlashLightOn, 0) > 0) {
          this.vars.timeFlashLightOn -= 0.1;
        }
      }
      yield;
    }
  }

  *whenGreenFlagClicked() {
    for (let i = 0; i < 10; i++) {
      this.createClone();
      yield* this.wait(3.5);
      yield;
    }
    for (let i = 0; i < 15; i++) {
      this.createClone();
      yield* this.wait(3.5);
      this.sprites["Fast"].createClone();
      yield* this.wait(1.75);
      yield;
    }
    for (let i = 0; i < 20; i++) {
      this.createClone();
      yield* this.wait(2.8);
      this.sprites["Fast"].createClone();
      yield* this.wait(1.75);
      this.sprites["Strong"].createClone();
      yield* this.wait(1.75);
      yield;
    }
    for (let i = 0; i < 25; i++) {
      this.createClone();
      yield* this.wait(2.8);
      this.sprites["Fast"].createClone();
      yield* this.wait(1.75);
      this.sprites["Strong"].createClone();
      yield* this.wait(1.75);
      this.sprites["VeryFast"].createClone();
      yield* this.wait(1.75);
      yield;
    }
    for (let i = 0; i < 25; i++) {
      this.createClone();
      yield* this.wait(1.85);
      this.sprites["Fast"].createClone();
      yield* this.wait(1.75);
      this.sprites["Strong"].createClone();
      yield* this.wait(1.75);
      this.sprites["VeryFast"].createClone();
      yield* this.wait(1.75);
      this.sprites["VeryStrong"].createClone();
      yield* this.wait(1.75);
      yield;
    }
    for (let i = 0; i < 25; i++) {
      this.createClone();
      yield* this.wait(2.8);
      this.sprites["Fast"].createClone();
      yield* this.wait(1.75);
      this.sprites["Strong"].createClone();
      yield* this.wait(1.75);
      this.sprites["VeryFast"].createClone();
      yield* this.wait(1.75);
      this.sprites["VeryStrong"].createClone();
      yield* this.wait(1.75);
      this.sprites["ScaryFingerMan"].createClone();
      yield* this.wait(1.75);
      yield;
    }
    for (let i = 0; i < 10; i++) {
      this.sprites["MrBossGuy"].createClone();
      yield* this.wait(10);
      for (let i = 0; i < 100; i++) {
        this.createClone();
        yield* this.wait(1.25);
        this.sprites["Fast"].createClone();
        yield* this.wait(1.75);
        this.sprites["Strong"].createClone();
        yield* this.wait(1.75);
        this.sprites["VeryFast"].createClone();
        yield* this.wait(1.75);
        this.sprites["VeryStrong"].createClone();
        yield* this.wait(1.75);
        yield;
      }
      yield;
    }
    this.sprites["TheFinalBossGrandpaJoe"].createClone();
  }

  *startAsClone5() {
    while (true) {
      if (this.touching(Color.rgb(255, 255, 255))) {
        this.broadcast("dead");
      }
      yield;
    }
  }

  *whenGreenFlagClicked2() {
    while (true) {
      yield* this.wait(0.1);
      this.stage.vars.timeSurvived += 0.1;
      yield;
    }
  }

  *whenGreenFlagClicked3() {
    this.stage.vars.timeSurvived = 0;
    this.stage.watchers.timeSurvived.visible = false;
    this.stage.vars.murdersCommited = 0;
    while (true) {
      if (this.random(1, 2) === 2) {
        this.y = this.random(-150, -75);
        this.x = this.random(-227, 227);
        this.effects.ghost = 99;
      } else {
        this.y = this.random(150, 75);
        this.x = this.random(-227, 227);
        this.effects.ghost = 99;
      }
      yield;
    }
  }
}
