/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Sprite3 extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Sprite3/costumes/costume1.svg", {
        x: 256.8350487540628,
        y: 91.14924160346698,
      }),
      new Costume("costume2", "./Sprite3/costumes/costume2.svg", {
        x: 234.75754922597966,
        y: 159.53118187617338,
      }),
    ];

    this.sounds = [new Sound("pop", "./Sprite3/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.BROADCAST, { name: "dead" }, this.whenIReceiveDead),
      new Trigger(
        Trigger.BROADCAST,
        { name: "granpa joe is coming" },
        this.whenIReceiveGranpaJoeIsComing
      ),
    ];
  }

  *whenGreenFlagClicked() {
    this.costume = "costume1";
    this.visible = false;
  }

  *whenIReceiveDead() {
    this.stage.watchers.timeSurvived.visible = true;
    this.visible = true;
    /* TODO: Implement stop all */ null;
  }

  *whenIReceiveGranpaJoeIsComing() {
    this.costume = "costume2";
  }
}
