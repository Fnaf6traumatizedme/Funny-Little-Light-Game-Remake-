/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Fast extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Fast/costumes/costume1.svg", {
        x: 22,
        y: 49.82742130950976,
      }),
    ];

    this.sounds = [new Sound("pop", "./Fast/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(Trigger.CLONE_START, this.startAsClone2),
      new Trigger(Trigger.CLONE_START, this.startAsClone3),
      new Trigger(Trigger.CLONE_START, this.startAsClone4),
      new Trigger(Trigger.CLONE_START, this.startAsClone5),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
    ];

    this.vars.timeFlashLightOn = -1.942890293094024e-16;
  }

  *startAsClone() {
    while (true) {
      if (this.compare(this.vars.timeFlashLightOn, 1.49) > 0) {
        this.stage.vars.murdersCommited++;
        yield* this.wait(0);
        this.deleteThisClone();
      }
      yield;
    }
  }

  *startAsClone2() {
    while (true) {
      yield* this.glide(
        12,
        this.sprites["Sprite1"].x,
        this.sprites["Sprite1"].y
      );
      yield;
    }
  }

  *startAsClone3() {
    this.visible = true;
  }

  *startAsClone4() {
    while (true) {
      if (this.touching(Color.rgb(255, 251, 150))) {
        this.vars.timeFlashLightOn += 0.3;
        this.effects.ghost = 0;
      } else {
        this.effects.ghost = 99;
        if (this.compare(this.vars.timeFlashLightOn, 0) > 0) {
          this.vars.timeFlashLightOn -= 0.1;
        }
      }
      yield;
    }
  }

  *startAsClone5() {
    while (true) {
      if (this.touching(Color.rgb(255, 255, 255))) {
        this.broadcast("dead");
      }
      yield;
    }
  }

  *whenGreenFlagClicked() {
    this.stage.vars.timeSurvived = 0;
    this.stage.watchers.timeSurvived.visible = false;
    this.stage.vars.murdersCommited = 0;
    while (true) {
      if (this.random(1, 2) === 2) {
        this.y = this.random(-150, -75);
        this.x = this.random(-227, 227);
        this.effects.ghost = 99;
      } else {
        this.y = this.random(150, 75);
        this.x = this.random(-227, 227);
        this.effects.ghost = 99;
      }
      yield;
    }
  }
}
